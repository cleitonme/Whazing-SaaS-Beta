import { register } from 'register-service-worker'

register(process.env.SERVICE_WORKER_FILE, {
  ready() {
    console.log('Service worker is active.')
  },
  registered() {
    console.log('Service worker has been registered.')
  },
  cached() {
    console.log('Content has been cached for offline use.')
  },
  updatefound() {
    console.log('New content is downloading.')
  },
  updated() {
    console.log('New content is available; please refresh.')
  },
  offline() {
    console.log('No internet connection found. App is running in offline mode.')
  },
  error(err) {
    console.error('Error during service worker registration:', err)
  },
  push(event) {
    // Lida com as notificações push
    if (event.data) {
      const payload = event.data.json()
      const title = payload.title || 'Nova notificação'
      const options = {
        body: payload.body || 'Você tem uma nova notificação.',
        icon: payload.icon || '/public/whatsapp-logo.png',
        badge: payload.badge || '/public/whatsapp-logo.png'
      }

      event.waitUntil(
        self.registration.showNotification(title, options)
      )
    }
  },
  notificationclick(event) {
    // Lida com o clique na notificação
    event.notification.close()
    event.waitUntil(
      clients.openWindow(event.notification.data.url)
    )
  }
})
