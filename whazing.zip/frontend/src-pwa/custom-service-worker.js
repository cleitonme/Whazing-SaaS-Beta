// Este arquivo só será usado se o modo workboxPluginMode for "InjectManifest" no quasar.conf.js

import { precacheAndRoute } from 'workbox-precaching'
import { clientsClaim, setCacheNameDetails } from 'workbox-core'
import { CacheFirst, StaleWhileRevalidate } from 'workbox-strategies'

// Ativando a abordagem de controle de cache
setCacheNameDetails({
  prefix: 'pwa',
  suffix: 'v1',
  precache: 'precache',
  runtime: 'runtime'
})

// Garante que o service worker será imediatamente controlado
clientsClaim()

// Pré-cache de arquivos essenciais
precacheAndRoute(self.__WB_MANIFEST)

// Estratégia de cache para arquivos estáticos
self.addEventListener('fetch', (event) => {
  if (event.request.url.includes('images')) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        return cachedResponse || fetch(event.request).then((response) => {
          return caches.open('runtime').then((cache) => {
            cache.put(event.request, response.clone())
            return response
          })
        })
      })
    )
  }
})

// Adicionando a estratégia de cache para as notificações push
self.addEventListener('push', (event) => {
  if (event.data) {
    const payload = event.data.json()
    const title = payload.title || 'Nova notificação'
    const options = {
      body: payload.body || 'Você tem uma nova mensagem.',
      icon: payload.icon || '/public/whatsapp-logo.png',
      badge: payload.badge || '/public/whatsapp-logo.png'
    }

    event.waitUntil(
      self.registration.showNotification(title, options)
    )
  }
})

// Lida com o clique na notificação
self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  event.waitUntil(
    clients.openWindow(event.notification.data.url)
  )
})
