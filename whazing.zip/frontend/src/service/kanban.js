import request from 'src/service/request'

export function CriarKanban (data) {
  return request({
    url: '/kanban/',
    method: 'post',
    data
  })
}

export function ListarKanbans (params) {
  return request({
    url: '/kanban/',
    method: 'get',
    params
  })
}

export function AlterarKanban (data) {
  return request({
    url: `/kanban/${data.id}`,
    method: 'put',
    data
  })
}

export function DeletarKanban (data) {
  return request({
    url: `/kanban/${data.id}`,
    method: 'delete'
  })
}

export function ConsultarContatosKanbanService (params) {
  return request({
    url: '/kanban/list/',
    method: 'get',
    params
  })
}

export function AlterarContactKanban(data) {
  return request({
    url: `/kanban/contact/${data.contactId}`, // Ajuste a URL com o contactId
    method: 'put',
    data
  })
}

export function AlterarContactKanban2(data) {
  return request({
    url: `/kanban/contact2/${data.contactId}`, // Ajuste a URL com o contactId
    method: 'put',
    data
  })
}

export function UpdateUsuarioKanban(userId, data) {
  return request({
    url: `/kanban/user/${userId}`,
    method: 'put',
    data
  })
}

export function DadosKanban(userId) {
  return request({
    url: `/kanban/user/${userId}`,
    method: 'get'
  })
}
