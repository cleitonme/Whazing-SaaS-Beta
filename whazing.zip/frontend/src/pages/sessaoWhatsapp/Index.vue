<template>
  <div class="full-width">
    <q-card flat class="no-shadow">
      <q-tabs
        v-model="tab"
        dense
        align="justify"
      >
        <q-tab name="Canais" label="Canais" />
        <q-tab name="Api" label="Api"  v-if="userProfile === 'admin'"/>
      </q-tabs>
      <q-separator />

      <q-tab-panels v-model="tab" animated>
        <q-tab-panel name="Canais" class="q-pa-none">
          <canais/>
        </q-tab-panel>

        <q-tab-panel name="Api" class="q-pa-none">
          <api/>
        </q-tab-panel>
      </q-tab-panels>
    </q-card>
  </div>
</template>

<script>
import canais from './IndexChannel.vue'
import api from './api/Index.vue'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  data () {
    return {
      tab: 'Canais',
      splitterModel: 20,
      userProfile: 'user'
    }
  },
  components: {
    canais,
    api
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    }
  },
  mounted () {
    this.loadColors()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>
