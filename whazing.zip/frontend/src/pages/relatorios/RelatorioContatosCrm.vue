<template>
  <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-card bordered>
      <q-card-section>
        <div class=text-h6 q-px-sm  :class="$q.dark.isActive ? ('text-color-dark') : ''">
          Relatório de Contatos </div>
      </q-card-section>
      <q-card-section class="q-pt-none">
        <fieldset>
          <legend class="q-px-sm">Filtros</legend>
          <div class="row q-gutter-md items-end">
            <div class="col-xs-12 col-sm-7 grow text-center">
              <q-select
                square
                outlined
                v-model="pesquisa.kanbans"
                multiple
                :options="kanbans"
                use-chips
                option-value="id"
                option-label="name"
                emit-value
                map-options
                dropdown-icon="add"
              >
                <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                  <q-item
                    v-bind="itemProps"
                    v-on="itemEvents"
                  >
                    <q-item-section>
                      <q-item-label v-html="opt.name"></q-item-label>
                    </q-item-section>
                    <q-item-section side>
                      <q-checkbox
                        :value="selected"
                        @input="toggleOption(opt)"
                      />
                    </q-item-section>
                  </q-item>
                </template>
                <template v-slot:selected-item="{opt}">
                  <q-chip
                    dense
                    square
                    color="white"
                    text-color="primary"
                    class="q-ma-xs text-body1"
                  >
                    <q-icon
                      :style="`color: ${opt.color}`"
                      name="mdi-pound-box-outline"
                      size="28px"
                      class="q-mr-sm"
                    />
                    {{ opt.name }}
                  </q-chip>
                </template>
              </q-select>
            </div>
            <div class="col-grow text-center">
              <q-btn
                class="q-mr-sm"
                color="info"
                label="Gerar"
                icon="refresh"
                @click="gerarRelatorio"
              />
              <q-btn
                class="q-mr-sm"
                color="black"
                icon="print"
                label="Imprimir"
                @click="printReport('tRelatorioContatosEtiquetas')"
              />
              <q-btn
                color="green"
                label="Excel"
                @click="exportTable('tRelatorioContatosEtiquetas')"
              />
            </div>
          </div>
        </fieldset>
      </q-card-section>
    </q-card>

    <div class="row">
      <div class="col-xs-12 q-mt-sm">
        <div
          class="tableLarge q-ma-sm q-markup-table q-table__container q-table__card q-table--cell-separator q-table--flat q-table--bordered q-table--no-wrap"
          id="tRelatorioContatosEtiquetas"
        >
          <table
            id="tableRelatorioContatos"
            class="q-pb-md q-table q-tabs--dense "
          >
            <thead>
            <tr>
              <td
                v-for="col in bl_sintetico ? columns.filter(c => c.name == opcoesRelatorio.agrupamento) : columns"
                :key="col.name"
              >
                {{ col.label }}
              </td>
            </tr>
            </thead>
            <tbody>
            <template v-if="!bl_sintetico">
              <tr
                v-for="row in contatos"
                :key="row.number"
              >
                <td
                  v-for="col in columns"
                  :key="col.name +'-'+ row.id"
                  :class="col.class"
                  :style="col.style"
                >
                  {{ col.format !== void 0 ? col.format(row[col.field], row) : row[col.field] }}
                </td>
              </tr>
            </template>

            <template>
              <div>
                <!-- tabela existente -->
                <div class="q-mt-md q-pa-md text-right text-weight-bold">
                  Total: {{ calcularTotalKanbanPrice }}
                </div>
              </div>
            </template>

            </tbody>
          </table>
        </div>
      </div>
    </div>

    <ccPrintModelLandscape
      id="slotTableRelatorioContatos"
      :imprimirRelatorio="imprimir"
      title="Relatório de Contatos por Etiquetas"
      :styleP="`
      table { width: 100%; font-size: 10px; border-spacing: 1; border-collapse: collapse;  }
      #tableReport tr td { border:1px solid #DDD; padding-left: 10px; padding-right: 10px;  }
      #tableReport thead tr:nth-child(1) td { text-align: center; padding: 5px; font-weight: bold; color: #000; background: lightgrey; opacity: 1; }
      #lineGroup { background: #f8f8f8; line-height: 30px; }
      #quebraAgrupamentoRelatorio { border-bottom: 1px solid black !important; }
      #st_nome, #st_tipo_atendimento, #st_status_faturamento, #st_convenio, #st_nome_profissional, #st_status, #st_nome_unidade, #st_nome_profissional { width: 200px; word-wrap: normal !important; white-space: normal !important; }
      #dt_atendimento_unidade { width: 100px; text-align: center }
      `"
    >
      <template v-slot:body>
        <table class="q-pb-md q-table q-tabs--dense ">
          <thead>
          <tr>
            <td
              v-for="col in bl_sintetico ? columns.filter(c => c.name == opcoesRelatorio.agrupamento) : columns"
              :key="col.name"
            >
              {{ col.label }}
            </td>
          </tr>
          </thead>
          <tbody>
          <template v-if="!bl_sintetico">
            <tr
              v-for="row in contatos"
              :key="row.number"
            >
              <td
                v-for="col in columns"
                :key="col.name +'-'+ row.id"
                :class="col.class"
                :style="col.style"
              >
                {{ col.format !== void 0 ? col.format(row[col.field], row) : row[col.field] }}
              </td>
            </tr>
          </template>

          </tbody>
        </table>
      </template>
    </ccPrintModelLandscape>

  </div>
</template>

<script>
import { format, parseISO } from 'date-fns'
import ccPrintModelLandscape from './ccPrintModelLandscape'
import XLSX from 'xlsx'
import { RelatorioContatos } from 'src/service/estatisticas'
import { ListarCores } from 'src/service/configuracoesgeneral'
import { ListarKanbans } from 'src/service/kanban'

export default {
  name: 'RelatorioContatosCRM',
  components: { ccPrintModelLandscape },
  props: {
    moduloAtendimento: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      userProfile: 'user',
      data: null,
      bl_sintetico: false,
      contatos: [],
      kanbans: [],
      columns: [
        { name: 'name', label: 'Nome', field: 'name', align: 'left', style: 'width: 300px', format: v => this.replaceEmojis(v) },
        { name: 'number', label: 'WhatsApp', field: 'number', align: 'center', style: 'width: 300px' },
        { name: 'email', label: 'Email', field: 'email', style: 'width: 500px', align: 'left' },
        {
          name: 'kanbanId',
          label: 'Lane',
          field: 'kanbanId',
          style: 'width: 500px',
          align: 'left',
          format: (value) => {
            if (!value) return ''

            if (!Array.isArray(value)) {
              const kanban = this.kanbans.find(k => k.id === value)
              return kanban ? kanban.name : ''
            }

            return value.map(kanbanId => {
              const kanban = this.kanbans.find(k => k.id === kanbanId)
              return kanban ? kanban.name : ''
            }).filter(Boolean).join(', ')
          }
        },
        {
          name: 'kanbanPrice',
          label: '$',
          field: 'kanbanPrice',
          style: 'width: 100px',
          align: 'left',
          format: (val) => val ? `$ ${Number(val).toFixed(2)}` : '$ 0.00'
        },
        { name: 'commentary', label: 'Comentário', field: 'commentary', style: 'width: 500px', align: 'left' },
        {
          name: 'deadline',
          label: 'Data',
          field: 'deadline',
          style: 'width: 500px',
          align: 'left',
          format: (value) => {
            if (!value) return ''
            return format(parseISO(value), 'dd/MM/yyyy')
          }
        }
      ],
      pesquisa: {
        kanbans: []
      },
      ExibirTabela: true,
      imprimir: false
    }
  },
  computed: {
    calcularTotalKanbanPrice() {
      const total = this.contatos.reduce((total, row) => total + (Number(row.kanbanPrice) || 0), 0)
      return `$ ${total.toFixed(2)}`
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    },
    replaceEmojis (str) {
      var ranges = [
        '[\u00A0-\u269f]',
        '[\u26A0-\u329f]',
        // The following characters could not be minified correctly
        // if specifed with the ES6 syntax \u{1F400}
        '[🀄-🧀]'
        // '[\u{1F004}-\u{1F9C0}]'
      ]
      return str.replace(new RegExp(ranges.join('|'), 'ug'), '')
    },
    sortObject (obj) {
      return Object.keys(obj)
        .sort().reduce((a, v) => {
          a[v] = obj[v]
          return a
        }, {})
    },
    printReport (idElemento) {
      this.imprimir = !this.imprimir
    },
    exportTable () {
      const json = XLSX.utils.table_to_sheet(
        document.getElementById('tableRelatorioContatos'),
        { raw: true }
      )
      for (const col in json) {
        if (col[0] == 'J') {
          json[col].t = 'n'
          json[col].v = json[col].v.replace(/\./g, '').replace(',', '.')
          // json[col].f = `VALUE(${json[col].v})`
        }
      }
      const wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, json, 'Relatório Contatos')
      XLSX.writeFile(wb, 'relatorio-contatos-lane.xlsx')
    },
    async listarKanbans () {
      const { data } = await ListarKanbans({ showAll: true })
      this.kanbans = data
    },
    async gerarRelatorio () {
      if (!this.pesquisa.kanbans.length) {
        this.$notificarErro('Ops... Para gerar o relatório, é necessário selecionar pelo menos um Lane.')
        return
      }
      const { data } = await RelatorioContatos(this.pesquisa)
      this.contatos = data.contacts
    }
  },
  beforeMount () {
    this.userProfile = localStorage.getItem('profile')
    this.listarKanbans()
  },
  async mounted () {
    this.loadColors()
    // this.gerarRelatorio()
  }
}
</script>

<style scoped>
.text-right {
  text-align: right;
}

/* table {
  max-height: 300px;
  position: relative;
} */

thead tr:nth-child(1) td {
  color: #000;
  background: lightgrey;
  position: sticky;
  opacity: 1;
  top: 0;
  z-index: 1000;
}

.tableSmall {
  max-height: calc(100vh - 130px);
  height: calc(100vh - 130px);
}

.tableLarge {
  max-height: calc(100vh - 220px);
  height: calc(100vh - 220px);
}
</style>
