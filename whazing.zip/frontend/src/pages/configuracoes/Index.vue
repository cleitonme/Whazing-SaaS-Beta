<template>
  <div class="mass-container container-rounded-10" :class="$q.dark.isActive ? 'text-color-dark bg-grey-10' : 'container-border'" v-if="userProfile === 'admin'">
    <q-list class="text-weight-medium">
      <q-item-label header :class="['text-bold text-h6 q-mb-lg', $q.dark.isActive ? 'text-color-dark' : 'text-black']">
        Configurações
      </q-item-label>
      <q-item-label caption class="q-mt-lg q-pl-sm">Módulo: Atendimento</q-item-label>
      <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Agrupar mensagens tickets diferentes</q-item-label>
          <q-item-label caption>Ativando essa opção todas mensagens serão exibidas tickets como se fosse o mesmo.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="GroupTicketsMessages" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="GroupTicketsMessages === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('GroupTicketsMessages')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Reabrir tickets anteriores(essa opção faz metricas ficar com dados incorretos)</q-item-label>
          <q-item-label caption>Com essa opção ativada caso já exista ticket fechada ele vai abrir ele novamente e não criar um ticket novo.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ReopenTicket" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="ReopenTicket === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('ReopenTicket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Visualizar apenas mensagens das filas que o usuário pertence</q-item-label>
          <q-item-label caption>Ativando essa opção mensagens são separadas por fila, usuários não podem ver mensagens não fazem parte fila deles</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="MessagesforTicket" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="MessagesforTicket === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('MessagesforTicket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Administrador modo auditoria</q-item-label>
          <q-item-label caption>Tickets acessados pelo administrador não será marcados como lidos</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="auditMode" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="auditMode === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('auditMode')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Não visualizar Tickets Privados já atribuidos à outros usuários</q-item-label>
          <q-item-label caption>Somente o usuário responsável pelo ticket Privado e/ou os administradores visualizarão a
            atendimento.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="NotViewAssignedTickets" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="NotViewAssignedTickets === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('NotViewAssignedTickets')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Não visualizar Tickets no ChatBot</q-item-label>
          <q-item-label caption>Somente administradores poderão visualizar tickets que estivem interagindo com o
            ChatBot.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="NotViewTicketsChatBot" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="NotViewTicketsChatBot === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('NotViewTicketsChatBot')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Habilitar guia de atendimento de Chatbots</q-item-label>
          <q-item-label caption> Habilitando esta opção será adicionada uma guia de atendimento exclusiva para os chatbots. </q-item-label>
        </q-item-section>

      <q-item-section avatar>
        <q-toggle
            v-model="chatbotLane"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="chatbotLane === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('chatbotLane')"
        />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Habilitar ocultas guia de atendimento sem tickets</q-item-label>
          <q-item-label caption>Habilitando esta opção somente guia de atendimento com tickets será visivel.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="hidetab" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="hidetab === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('hidetab')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="canAccessPage">
        <q-item-section>
          <q-item-label>Habilitar notificações de grupos</q-item-label>
          <q-item-label caption>Habilitando esta opção notificações de mensagens grupos aparece.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="groupnotification" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="groupnotification === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('groupnotification')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Somente administradores podem acessar os lista de contatos</q-item-label>
          <q-item-label caption>Somente os administradores visualizarão lista de contatos no sistema.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ContactAdmin" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="ContactAdmin === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('ContactAdmin')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Forçar atendimento via Carteira</q-item-label>
          <q-item-label caption>Caso o contato tenha carteira vínculada, o sistema irá direcionar o atendimento somente
            para os donos da carteira de clientes.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="DirectTicketsToWallets" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="DirectTicketsToWallets === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('DirectTicketsToWallets')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Listar apenas os contatos da carteira do Usuario</q-item-label>
          <q-item-label caption>Irá listar apenas os contatos da carteira que tiver vinculado ao usuario</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="userContactWallet" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="userContactWallet === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('userContactWallet')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Fluxo ativo para o Bot de atendimento</q-item-label>
          <q-item-label caption>Fluxo a ser utilizado pelo Bot para os novos atendimentos</q-item-label>
        </q-item-section>
        <q-btn  @click="resetarFluxoAtivo"
            flat
            icon="mdi-replay"
            color="negative"
            class="bg-padrao btn-rounded" >
          <q-tooltip content-class="bg-negative text-bold">
            Resetar Fluxo Chatbot
          </q-tooltip>
        </q-btn>
        <q-item-section avatar>
          <q-select style="width: 300px" outlined dense v-model="botTicketActive" :options="listaChatFlow" map-options
            emit-value option-value="id" option-label="name" @input="atualizarConfiguracao('botTicketActive')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="canAccessPage">
        <q-item-section>
          <q-item-label>Ignorar Mensagens de Grupo</q-item-label>
          <q-item-label caption>Habilitando esta opção o sistema não abrirá ticket para grupos</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ignoreGroupMsg" false-value="disabled" true-value="enabled" checked-icon="check" keep-color
            :color="ignoreGroupMsg === 'enabled' ? 'green' : 'negative'" size="md" unchecked-icon="clear"
            @input="atualizarConfiguracao('ignoreGroupMsg')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Ignorar Mensagens Enviadas fora do aplicativo</q-item-label>
          <q-item-label caption>Habilitando esta opção o sistema não vai baixar mensagens que você enviar outras prataformas como wasender por exemplo</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="IgnoreMessageExt" false-value="disabled" true-value="enabled" checked-icon="check" keep-color
                    :color="IgnoreMessageExt === 'enabled' ? 'green' : 'negative'" size="md" unchecked-icon="clear"
                    @input="atualizarConfiguracao('IgnoreMessageExt')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Recusar chamadas no Whatsapp</q-item-label>
          <q-item-label caption>Quando ativo, as ligações de aúdio e vídeo serão recusadas,
            automaticamente.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="rejectCalls" false-value="disabled" true-value="enabled" checked-icon="check" keep-color
            :color="rejectCalls === 'enabled' ? 'green' : 'negative'" size="md" unchecked-icon="clear"
            @input="atualizarConfiguracao('rejectCalls')" />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="rejectCalls === 'enabled'">
        <div class="col-12">
          <q-input v-model="callRejectMessage" type="textarea" autogrow dense outlined
            label="Mensagem ao rejeitar ligação:" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('callRejectMessage')" />
        </div>
      </div>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Permitir que usuário desabilite a assinatura</q-item-label>
          <q-item-label caption>Os usuários poderão desativar a assinatura das mensagens</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="userDisableSignature" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="userDisableSignature === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('userDisableSignature')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Usuarios podem espiar ticket</q-item-label>
          <q-item-label caption>Desativando essa opção somente administradores podem ver mensagens antes de iniciar atendimento</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="spyticket" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="spyticket === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('spyticket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Usuarios podem reabrir ticket</q-item-label>
          <q-item-label caption>Desativando essa opção somente administradores podem reabrir ticket fechados</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="userReopenTicket" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="userReopenTicket === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('userReopenTicket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Contador nas tabs superiores (Privados/Grupos)</q-item-label>
          <q-item-label caption> Habilitando esta opção o usuário irá visualizar os tickcets com mensagens abertas nas tabs superiores de conversas privadas e grupos. </q-item-label>
        </q-item-section>

      <q-item-section avatar>
        <q-toggle
            v-model="universalCounter"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="universalCounter === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('universalCounter')"
        />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
<q-item-label>Resolver atendimento sem interação automaticamente</q-item-label>
<q-item-label caption>Caso não for respondido pelo contato o ticket vai se fechar automaticamente.</q-item-label>
        </q-item-section>

      <q-item-section avatar>
        <q-toggle
            v-model="autoClose"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="autoClose === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('autoClose')"
        />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="autoClose === 'enabled'">
        <div class="col-12">
          <q-select
            v-model="autoCloseTime"
            :options="tempoOptions"
            outlined
            label="Escolha uma opção (tempo em minutos)"
            input-style="min-height: 6vh; max-height: 9vh;"
            debounce="700"
            @input="atualizarConfiguracao('autoCloseTime')"
          />
        </div>
      </div>

      <div class="row q-px-md" v-if="autoClose === 'enabled'">
        <div class="col-12">
          <q-input
            v-model="autoCloseMessage"
            type="textarea"
            autogrow
            dense
            outlined
            label="Mensagem de encerramento"
            input-style="min-height: 6vh; max-height: 9vh;"
            debounce="700"
            @input="atualizarConfiguracao('autoCloseMessage')"
          />
        </div>
      </div>

      <q-item tag="label" v-ripple>
        <q-item-section>
<q-item-label>Se atendente demorar responder voltar tickets aos Pendentes</q-item-label>
<q-item-label caption>Caso o atendendete demorar a responder o contato o ticket vai voltar automaticamente para os Tickets pedentes.</q-item-label>
        </q-item-section>

      <q-item-section avatar>
        <q-toggle
            v-model="autoPending"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="autoPending === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('autoPending')"
        />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="autoPending === 'enabled'">
        <div class="col-12">
          <q-input
              v-model="autoPendingTime"
              type="number"
              label="Tempo em minutos para voltar aos Pendentes"
              dense
              outlined
              autogrow
              debounce="700"
              input-style="min-height: 6vh; max-height: 9vh;"
              @input="atualizarConfiguracao('autoPendingTime')"
            />
        </div>
      </div>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Máximo de vezes que a mensagem de horário de atendimento deve ser enviada para o cliente.</q-item-label>
            <q-item-label caption>Insira aqui a quantidade de vezes que a mensagem de ausência pode ser enviada para cada atendimento...</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-input
              v-model="maxRetriesBusinessHours"
              type="number"
              dense
              outlined
              debounce="700"
              @input="atualizarConfiguracao('maxRetriesBusinessHours')"
              style="width: 300px"
            />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Quantidades de tickets abertos será carregado na tela de atendimento.</q-item-label>
          <q-item-label caption>Insira aqui a quantidade de tickets que será carregado na tela de atendimento...</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-input
            v-model="TicketsLimitOpen"
            type="number"
            dense
            outlined
            debounce="700"
            @input="atualizarConfiguracao('TicketsLimitOpen')"
            style="width: 300px"
          />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Quantidades de tickets pendentes será carregado na tela de atendimento.</q-item-label>
          <q-item-label caption>Insira aqui a quantidade de tickets que será carregado na tela de atendimento...</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-input
            v-model="TicketsLimitPending"
            type="number"
            dense
            outlined
            debounce="700"
            @input="atualizarConfiguracao('TicketsLimitPending')"
            style="width: 300px"
          />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Quantidades de tickets fechados será carregado na tela de atendimento.</q-item-label>
            <q-item-label caption>Insira aqui a quantidade de tickets que será carregado na tela de atendimento...</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-input
              v-model="TicketsLimitClosed"
              type="number"
              dense
              outlined
              debounce="700"
              @input="atualizarConfiguracao('TicketsLimitClosed')"
              style="width: 300px"
            />
        </q-item-section>
      </q-item>

      <q-item-label caption class="q-mt-lg q-pl-sm">Módulo: KANBAN</q-item-label>
      <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Listar contatos de tickets sem usuarios no Kanban</q-item-label>
          <q-item-label caption>Com essa opção ativada caso exista um ticket sem usuário atribuido será mostrado contato no kanban.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanUserNull" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanUserNull === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanUserNull')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Listar contatos que ticket esteja fechado</q-item-label>
          <q-item-label caption>Com essa opção desativado não vai mostrar contato no kanban se ticket estiver fechado somente tickets abertos ou pendentes.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanTicketClosed" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanTicketClosed === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanTicketClosed')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Separar lista de lane por usuario</q-item-label>
          <q-item-label caption>Com essa opção desativado, todos lanes são compartilhados entre usuarios e somente admin pode criar, editar ou apagar lane.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanforUser" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanforUser === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanforUser')" />
        </q-item-section>
      </q-item>

    </q-list>

<q-separator spaced />
  </div>
</template>

<script>
import { ListarChatFlow } from 'src/service/chatFlow'
import { ListarConfiguracoes, AlterarConfiguracao } from 'src/service/configuracoes'
import { MostrarPlano } from 'src/service/empresas'
export default {
  name: 'IndexConfiguracoes',
  data() {
    return {
      userProfile: 'user',
      tempoOptions: [
        { value: '10', label: '10 minutos' },
        { value: '60', label: '1 hora' },
        { value: '1440', label: '1 dia' },
        { value: '7200', label: '5 dias' },
        { value: '14400', label: '10 dias' }
      ],
      configuracoes: [],
      listaChatFlow: [],
      NotViewAssignedTickets: null,
      NotViewTicketsChatBot: null,
      ContactAdmin: null,
      DirectTicketsToWallets: null,
      botTicketActive: null,
      ignoreGroupMsg: null,
      userContactWallet: null,
      rejectCalls: null,
      userDisableSignature: null,
      sendGreetingAccepted: null,
      sendMsgTransfTicket: null,
      spyticket: null,
      userReopenTicket: null,
      universalCounter: null,
      autoClose: null,
      autoCloseTime: null,
      autoCloseMessage: '',
      chatbotLane: null,
      callRejectMessage: '',
      autoPendingTime: null,
      canAccessPage: false,
      autoPending: null,
      hidetab: null,
      maxRetriesBusinessHours: null,
      TicketsLimitOpen: null,
      TicketsLimitPending: null,
      TicketsLimitClosed: null,
      groupnotification: null,
      ReopenTicket: null,
      KanbanUserNull: null,
      KanbanTicketClosed: null,
      KanbanforUser: null,
      IgnoreMessageExt: null,
      GroupTicketsMessages: null,
      MessagesforTicket: null,
      auditMode: null
    }
  },
  methods: {
    async listarPlano() {
      try {
        const { data } = await MostrarPlano()
        this.canAccessPage = data.group !== false
      } catch (error) {
        console.error('Erro ao carregar o plano:', error)
      }
    },
    resetarFluxoAtivo() {
      this.botTicketActive = ''
      this.atualizarConfiguracao('botTicketActive')
    },
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoes()
      this.configuracoes = data
      this.configuracoes.forEach(el => {
        let value = el.value
        if (el.key === 'botTicketActive' && el.value) {
          value = +el.value
        }
        this.$data[el.key] = value
      })
    },
    async listarChatFlow() {
      const { data } = await ListarChatFlow()
      this.listaChatFlow = data.chatFlow
    },
    async atualizarConfiguracao(key) {
      if (key === 'autoCloseTime') {
        const params = { key, value: this.$data[key].value }
        try {
          await AlterarConfiguracao(params)
          this.$q.notify({
            type: 'positive',
            message: 'Configuração alterada!',
            progress: true,
            actions: [{ icon: 'close', round: true, color: 'white' }]
          })
        } catch (error) {
          console.error('error - AlterarConfiguracao', error)
          this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
          this.$notificarErro('Ocorreu um erro!', error)
        }
      } else {
        const params = { key, value: this.$data[key] }
        try {
          await AlterarConfiguracao(params)
          this.$q.notify({
            type: 'positive',
            message: 'Configuração alterada!',
            progress: true,
            actions: [{ icon: 'close', round: true, color: 'white' }]
          })
        } catch (error) {
          console.error('error - AlterarConfiguracao', error)
          this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
          this.$notificarErro('Ocorreu um erro!', error)
        }
      }
    }
  },
  async mounted() {
    this.listarPlano()
    this.userProfile = localStorage.getItem('profile')
    await this.listarConfiguracoes()
    await this.listarChatFlow()
  }
}
</script>

<style lang="scss" scoped></style>
