<template>
  <div class="q-pa-md" style="max-width: 100%">
    <q-card>
      <q-tabs
        v-model="tab"
        dense
        align="justify"
      >
        <q-tab name="Dashboard" label="Dashboard" />
        <q-tab name="empresas" label="Empresas" />
        <q-tab name="planos" label="Planos" />
        <q-tab name="ajuda" label="Ajuda" />
        <q-tab name="config" label="Configurações" />
        <q-tab name="whitelabel" label="White Label" />
      </q-tabs>
      <q-separator />

      <q-tab-panels v-model="tab" animated>
        <q-tab-panel name="Dashboard" class="q-pa-none">
          <dashboard/>
        </q-tab-panel>

        <q-tab-panel name="empresas">
          <empresa/>
        </q-tab-panel>

        <q-tab-panel name="planos">
          <planos/>
        </q-tab-panel>

        <q-tab-panel name="ajuda">
          <ajuda/>
        </q-tab-panel>

        <q-tab-panel name="config">
          <config/>
        </q-tab-panel>

        <q-tab-panel name="whitelabel">
          <whitelabel/>
        </q-tab-panel>

      </q-tab-panels>
    </q-card>
  </div>
</template>

<script>
import empresa from './empresa.vue'
import dashboard from './dashboard/index.vue'
import planos from './planos/Index.vue'
import ajuda from './ajuda/Index.vue'
import config from './config/Index.vue'
import whitelabel from './whitelabel/Index.vue'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  data () {
    return {
      tab: 'Dashboard', // Defina o nome da guia que deseja abrir por padrão
      innerTab: 'innerMails',
      splitterModel: 20
    }
  },
  components: {
    empresa,
    dashboard,
    planos,
    ajuda,
    config,
    whitelabel
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    }
  },
  mounted () {
    this.loadColors()
  }
}
</script>
