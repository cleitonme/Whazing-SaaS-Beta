<template>
  <q-dialog
    persistent
    :value="modalDespedida"
    @hide="fecharModal"
    @show="abrirModal"
  >
    <q-card
      class="q-pa-lg modal-container container-rounded-10"
    >

      <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ despedidaEdicao.id ? 'Editar': 'Criar' }} Despedida
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <q-card-section class="q-pa-lg container-border container-rounded-10">
        <div class="text-h6 font-family-main q-mb-md">
          Despedida
        </div>
        <q-input
          class="row col"
          rounded
          outlined
          style="margin-bottom: 15px;margin-right: 5px;"
          v-model="despedida.message"
          label="Despedida"
          autogrow
        />
        <div class="full-width" v-if="userProfile === 'admin' || userProfile === 'supervisor'">
          <q-checkbox
            v-model="despedida.global"
            label="Mostrar para todos"
          />
        </div>
      </q-card-section>
      <q-card-actions
        align="right"
        class="q-mt-md"
      >
        <q-btn
          label="Cancelar"
          color="negative"
          v-close-popup
          class="q-mr-md btn-rounded-50"
        />
        <q-btn
          label="Salvar"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          icon="eva-save-outline"
          @click="handleDespedida"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>

</template>

<script>
import { CriarDespedida, AlterarDespedida } from 'src/service/despedida'

export default {
  name: 'ModalDespedida',
  props: {
    modalDespedida: {
      type: Boolean,
      default: false
    },
    despedidaEdicao: {
      type: Object,
      default: () => {
        return { id: null, message: null, global: false }
      }
    }
  },
  data () {
    return {
      userProfile: 'user',
      despedida: {
        id: null,
        message: null,
        global: false
      }
    }
  },
  methods: {
    resetarDespedida () {
      this.despedida = {
        id: null,
        message: null,
        global: false
      }
    },
    fecharModal () {
      this.resetarDespedida()
      this.$emit('update:despedidaEdicao', { id: null })
      this.$emit('update:modalDespedida', false)
    },
    abrirModal () {
      if (this.despedidaEdicao.id) {
        this.despedida = { ...this.despedidaEdicao }
      } else {
        this.resetarDespedida()
      }
    },
    async handleDespedida () {
      try {
        this.loading = true
        if (this.despedida.id) {
          const { data } = await AlterarDespedida(this.despedida)
          this.$emit('modal-despedida:editada', data)
          this.$q.notify({
            type: 'info',
            progress: true,
            position: 'top',
            textColor: 'black',
            message: 'Despedida editado!',
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } else {
          const { data } = await CriarDespedida(this.despedida)
          this.$emit('modal-despedida:criada', data)
          this.$q.notify({
            type: 'positive',
            progress: true,
            position: 'top',
            message: 'Despedida criado!',
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        }
        this.loading = false
        this.fecharModal()
        // setTimeout(() => {
        //   window.location.reload();
        // }, 300);
      } catch (error) {
        console.error(error)
        this.$notificarErro('Ocorreu um erro ao criar o despedida', error)
      }
    }
  },
  mounted() {
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="scss" scoped>
</style>
