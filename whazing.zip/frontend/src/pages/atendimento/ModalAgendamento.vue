<template>
  <q-dialog
    persistent
    :value="modalAgendamento"
    @hide="fecharModal"
    @show="abrirModal"
  >
    <q-card class="q-pa-md modal-container container-rounded-10" style="max-width: 600px;">
      <q-overlay v-if="loading" class="bg-primary">
        <q-spinner color="white" size="50px" />
      </q-overlay>

      <q-card-section class="row items-center justify-between q-my-sm q-px-none">
        <div class="text-h6 text-center font-family-main col">
          Criar Novo Agendamento
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <q-card-section class="q-pa-sm container-border container-rounded-10">
        <div class="text-h6 font-family-main q-mb-sm">
          Mensagem
        </div>
        <div class="row items-center">
          <div class="col-xs-3 col-sm-2 col-md-1">
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-emoticon-happy-outline" />
              <q-tooltip>Emoji</q-tooltip>
              <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                <VEmojiPicker
                  style="width: 40vw"
                  :showSearch="true"
                  :emojisByRow="20"
                  labelSearch="Localizar..."
                  lang="pt-BR"
                  @select="onInsertSelectEmoji"
                />
              </q-menu>
            </q-btn>
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-variable" />
              <q-tooltip>Variáveis</q-tooltip>
              <q-menu touch-position>
                <q-list dense style="min-width: 100px">
                  <q-item
                    v-for="variavel in variaveis"
                    :key="variavel.label"
                    clickable
                    @click="onInsertSelectVariable(variavel.value)"
                    v-close-popup
                  >
                    <q-item-section>{{ variavel.label }}</q-item-section>
                  </q-item>
                </q-list>
              </q-menu>
            </q-btn>
          </div>
          <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm q-mt-sm">
            <textarea
              ref="inputEnvioMensagem"
              style="min-height: 15vh; max-height: 15vh;"
              class="q-pa-sm bg-white full-width"
              placeholder="Digite a mensagem"
              :value="agendamento.mensagem"
              @input="(v) => agendamento.mensagem = v.target.value"
            />
          </div>
        </div>

        <div class="full-width q-mt-sm">
          <q-file dense outlined v-model="agendamento.anexo" label="Escolha o arquivo" filled />
        </div>

        <div class="text-h6 font-family-main q-mb-sm q-mt-sm">
          Data para Enviar
        </div>
        <div class="row q-col-gutter-sm">
          <div class="col-xs-12 col-md-6">
            <q-select :options="schedule.options" v-model="schedule.selected" map-options outlined @input="onSelectSchedule" />
          </div>
          <div class="col-xs-12 col-md-6">
            <q-datetime-picker
              outlined
              stack-label
              label="Data/Hora Agendamento"
              mode="datetime"
              v-model="agendamento.dataParaEnviar"
              format24h
              :readonly="schedule.selected.value !== 'custom'"
            />
          </div>
          <div class="full-width q-mt-sm">
            <q-checkbox v-model="agendamento.repetir" label="Repetir agendamento" />
            <q-select
              v-if="agendamento.repetir"
              :options="periodo.options"
              v-model="agendamento.periodo"
              map-options
              outlined
            />
            <q-input
              v-if="agendamento.repetir"
              outlined
              label="Número de repetições"
              type="number"
              v-model="agendamento.repeticao"
            />
          </div>
        </div>
      </q-card-section>

      <q-card-actions align="right" class="q-mt-sm">
        <q-btn label="Cancelar" color="negative" v-close-popup class="q-mr-sm btn-rounded-50" />
        <q-btn
          :loading="loading"
          :disable="loading"
          label="Salvar"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          @click="handleAgendamento"
          icon="eva-save-outline"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { CriarAgendamento } from 'src/service/agendamentos'
import { add, format } from 'date-fns'
import { VEmojiPicker } from 'v-emoji-picker'

export default {
  name: 'ModalAgendamento',
  components: { VEmojiPicker },
  props: {
    modalAgendamento: {
      type: Boolean,
      default: false
    },
    ticketFocado: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      contatos: [],
      variaveis: [
        { label: 'Nome Completo', value: '{{name}}' },
        { label: 'Nome', value: '{{firstName}}' },
        { label: 'Saudação', value: '{{greeting}}' },
        { label: 'Telefone', value: '{{phoneNumber}}' },
        { label: 'Email do Contato', value: '{{email}}' },
        { label: 'Hora', value: '{{hour}}' },
        { label: 'Data', value: '{{date}}' }
      ],
      periodo: {
        selected: { label: 'Período', value: '' },
        options: [
          { label: 'Mensal', value: 'mensal' },
          { label: 'Semanal', value: 'semanal' },
          { label: 'Quinzenal', value: 'quinzena' },
          { label: 'Bimestral', value: 'bimestral' }
        ]
      },
      schedule: {
        selected: { label: 'Customizado', value: 'custom', func: null },
        options: [
          { label: 'Customizado', value: 'custom', func: null },
          { label: 'Em 30 minutos', value: '30_mins', func: () => add(new Date(), { minutes: 30 }) },
          { label: 'Amanhã', value: 'amanha', func: () => add(new Date(), { days: 1 }) },
          { label: 'Próxima semana', value: 'prox_semana', func: () => add(new Date(), { weeks: 1 }) }
        ]
      },
      agendamento: {
        contato: '',
        whatsapp: '',
        mensagem: '',
        anexo: null,
        dataParaEnviar: '',
        repetir: false,
        repeticao: 1,
        periodo: null
      },
      loading: false
    }
  },
  methods: {
    onInsertSelectVariable (variable) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filter:
      if (!variable) {
        return
      }
      // insert:
      self.txtContent = this.agendamento.mensagem
      self.txtContent = tmpStr.substring(0, startPos) + variable + tmpStr.substring(endPos, tmpStr.length)
      this.agendamento.mensagem = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + 1
      }, 10)
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      if (!emoji.data) {
        return
      }
      self.txtContent = this.agendamento.mensagem
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.agendamento.mensagem = self.txtContent
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    onSelectSchedule(newValue) {
      this.agendamento.dataParaEnviar = newValue.func ? format(newValue.func(), 'yyyy-MM-dd HH:mm') : null
    },
    fecharModal() {
      this.$emit('update:modalAgendamento', false)
    },
    abrirModal() {
      this.agendamento = {
        contato: '',
        whatsapp: '',
        mensagem: '',
        anexo: null,
        dataParaEnviar: '',
        repetir: false,
        repeticao: 1,
        periodo: null
      }
    },
    async handleAgendamento() {
      const { mensagem, dataParaEnviar, periodo, repetir, repeticao, anexo } = this.agendamento

      // Utilize this.ticketFocado diretamente
      const contatoId = this.ticketFocado.contactId
      const whatsapp = this.ticketFocado.whatsappId
      const periodoValue = periodo ? periodo.value : null

      if (!mensagem || !dataParaEnviar) {
        this.$q.notify({ type: 'negative', message: 'Preencha todos os campos obrigatórios.' })
        return
      }

      if (repetir && (isNaN(repeticao) || repeticao > 12)) {
        this.$q.notify({ type: 'negative', message: 'O campo repetição deve ser um número menor ou igual a 12.' })
        return
      }

      this.loading = true
      try {
        const formData = new FormData()
        formData.append('repetir', repetir)
        formData.append('repeticao', repeticao)
        formData.append('contatoId', contatoId)
        formData.append('whatsapp', whatsapp)
        formData.append('mensagem', mensagem)
        formData.append('dataParaEnviar', dataParaEnviar)
        formData.append('medias', anexo)

        if (periodoValue) formData.append('periodo', periodoValue)

        // Envia os dados do agendamento para o backend
        await CriarAgendamento(formData)
        this.$q.notify({ type: 'positive', message: 'Agendamento criado com sucesso!' })
        this.fecharModal()
      } catch (error) {
        console.error(error)
        this.$q.notify({ type: 'negative', message: 'Erro ao criar agendamento.' })
      } finally {
        this.loading = false
      }
    }
  }
}
</script>
