<template>
  <!-- <q-page class="q-py-xs q-px-md"> -->
  <div class="q-py-xs q-px-sm">
    <board />
  </div>
  <!-- </q-page> -->
</template>

<style></style>

<script>
import board from './Board'
import { ListarCores } from 'src/service/configuracoesgeneral'
export default {
  name: 'Kanban',
  components: {
    board
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    }
  },
  mounted () {
    this.loadColors()
  }
}
</script>
