<template>
  <div>
    <q-layout view="hHh Lpr lFf">

      <div class="header-mobile"
           v-if="this.$q.screen.lt.md && $route.name !== 'chat-interno' && $route.name !== 'atendimento' && $route.name !== 'chat-empty' && $route.name !== 'chat' && $route.name !== 'chat-contatos' && $route.name !== 'kanban' && $route.name !== 'chat-flow-builder' && $route.name !== 'ajuda'">

        <q-btn
          color="white"
          @click="leftDrawerOpen = !leftDrawerOpen"
          aria-label="Menu"
          icon="menu"
          size="lg"
          class="menu-icon-mobile">
        </q-btn>

      </div>
      <!--
            <div class="header" v-if="$route.name !== 'chat-interno' && $route.name !== 'atendimento' && $route.name !== 'chat-empty' && $route.name !== 'chat' && $route.name !== 'chat-contatos' && $route.name !== 'kanban' && $route.name !== 'chat-flow-builder' && $route.name !== 'ajuda'"
                 bordered
                 :class="{'header-buttons-mobile': this.$q.screen.lt.md}"
            >
              <q-toolbar
              >

                <div class="q-gutter-sm row items-center no-wrap">

                              <q-btn
                                dense
                                flat
                                @click="toggleSilentMode"
                                :icon="isSilentMode ? 'volume_off' : 'volume_up'"
                                :color="isSilentMode ? 'red' : 'green'"
                                size="xl"
                                class="header-buttons"
                                :class="{'header-buttons-dark' : $q.dark.isActive}"
                              >
                                <q-tooltip>
                                  {{ isSilentMode ? 'Modo Silencioso Ativado' : 'Modo Silencioso Desativado' }}
                                </q-tooltip>
                              </q-btn>

                              <q-btn
                                dense
                                flat
                                icon="notifications"
                                class="header-buttons" size="xl"
                                :class="{'header-buttons-dark' : $q.dark.isActive}"
                              >
                                <q-badge color="red"
                                         text-color="white"
                                         floating
                                         v-if="(this.notificacaoInternaNaoLida + parseInt(notifications_p.count)) > 0 || delayed > 0 || venceHoje > 0">
                                  {{ this.notificacaoInternaNaoLida + parseInt(notifications_p.count) + delayed + venceHoje }}
                                </q-badge>
                                <q-menu>
                                  <q-list style="min-width: 300px">
                                    <q-item v-if="(parseInt(notifications.count) + parseInt(notifications_p.count)) == 0 && delayed == 0 && venceHoje == 0">
                                      <q-item-section style="cursor: pointer;">
                                        Nada de novo por aqui!
                                      </q-item-section>
                                    </q-item>

                                    <q-item v-if="parseInt(notificacoesChat) > 0">
                                      <q-item-section avatar @click="() => $router.push({ name: 'interno' })" style="cursor: pointer;">
                                        <q-avatar style="width: 60px; height: 60px" color="primary" text-color="white">
                                          {{ notificacoesChat }}
                                        </q-avatar>
                                      </q-item-section>
                                      <q-item-section @click="() => $router.push({ name: 'chat-interno' })" style="cursor: pointer;">
                                        Novas mensagens não lidas no chat interno!
                                      </q-item-section>
                                    </q-item>

                                    <q-item v-if="parseInt(notificacaoInternaNaoLida) > 0">
                                      <q-item-section avatar @click="() => $router.push({ name: 'interno' })" style="cursor: pointer;">
                                        <q-avatar style="width: 60px; height: 60px" color="primary" text-color="white">
                                          {{ notificacaoInternaNaoLida }}
                                        </q-avatar>
                                      </q-item-section>
                                      <q-item-section @click="() => $router.push({ name: 'chat-interno' })" style="cursor: pointer;">
                                        Mensagens não lidas no chat interno!
                                      </q-item-section>
                                    </q-item>

                                    <q-item v-if="parseInt(notifications_p.count) > 0">
                                      <q-item-section avatar @click="() => $router.push({ name: 'atendimento' })" style="cursor: pointer;">
                                        <q-avatar style="width: 60px; height: 60px" color="primary" text-color="white">
                                          {{ notifications_p.count }}
                                        </q-avatar>
                                      </q-item-section>
                                      <q-item-section @click="() => $router.push({ name: 'atendimento' })" style="cursor: pointer;">
                                        Clientes pendentes na fila
                                      </q-item-section>
                                    </q-item>

                                    <q-item v-if="delayed > 0">
                                      <q-item-section avatar @click="() => $router.push({ name: 'tarefas' })" style="cursor: pointer;">
                                        <q-avatar style="width: 60px; height: 60px" color="red" text-color="white">
                                          {{ delayed }}
                                        </q-avatar>
                                      </q-item-section>
                                      <q-item-section @click="() => $router.push({ name: 'tarefas' })" style="cursor: pointer;">
                                        Existe {{ delayed }} tarefa(s) atrasada(s)!
                                      </q-item-section>
                                    </q-item>

                                    <q-item v-if="venceHoje > 0">
                                      <q-item-section avatar @click="() => $router.push({ name: 'tarefas' })" style="cursor: pointer;">
                                        <q-avatar style="width: 60px; height: 60px" color="orange" text-color="white">
                                          {{ venceHoje }}
                                        </q-avatar>
                                      </q-item-section>
                                      <q-item-section @click="() => $router.push({ name: 'tarefas' })" style="cursor: pointer;">
                                        Existe {{ venceHoje }} tarefa(s) que vence(m) hoje!
                                      </q-item-section>
                                    </q-item>

                                  </q-list>
                                </q-menu>
                                <q-tooltip>Notificações</q-tooltip>
                              </q-btn>

                                <q-btn  flat
                                       class="header-buttons" size="lg"
                                       :class="{'header-buttons-dark' : $q.dark.isActive}">
                                 <q-avatar :color="usuario.status === 'offline' ? 'negative' : 'positive'"
                                           text-color="white"
                                           size="25px"
                                           :icon="usuario.status === 'offline' ? 'mdi-account-off' : 'mdi-account-check'"
                                           rounded
                                 >
                                 </q-avatar>

                                 <q-menu>
                                   <q-list style="min-width: 100px">
                                     <cStatusUsuario @update:usuario="atualizarUsuario"
                                                     :usuario="usuario" />

                                   </q-list>
                                 </q-menu>

                                 <q-tooltip>
                                   {{ usuario.status === 'offline' ? 'Usuário Offiline' : 'Usuário Online' }}
                                 </q-tooltip>
                               </q-btn>

                   <q-btn
                     flat
                     class="header-buttons" size="lg"
                     :class="{'header-buttons-dark' : $q.dark.isActive}">
                     <q-avatar size="sm">
                       {{ $iniciaisString(username) }}
                     </q-avatar>
                     <q-menu>
                       <q-list style="min-width: 100px">
                         <q-item-label header> Olá! <b> {{ username }} </b> </q-item-label>
                         <q-item clickable
                                 v-close-popup
                                 @click="abrirModalUsuario">
                           <q-item-section>Perfil</q-item-section>
                         </q-item>
                         <q-item clickable
                                 v-close-popup
                                 @click="efetuarLogout">
                           <q-item-section>Sair</q-item-section>
                         </q-item>
                         <q-separator />
                         <q-item>
                           <q-item-section>
                             <vencimento />
                             <cSystemVersion  />
                           </q-item-section>
                         </q-item>

                       </q-list>
                     </q-menu>

                     <q-tooltip>Usuário</q-tooltip>
                   </q-btn>

                 </div>
               </q-toolbar>
             </div>
      -->
       <q-drawer v-model="leftDrawerOpen"
                 show-if-above
                 bordered
                 :mini="miniState"
                 @mouseover="miniState = false"
                 @mouseout="miniState = true"
                 @mouseover.stop="miniState = false"
                 mini-to-overlay
                 :content-class="$q.dark.isActive ? 'bg-black' : 'container-menu'">

         <div class="drawer-container">
           <!-- Header Fixo -->
           <div class="drawer-header">
             <q-item clickable v-ripple class="header-item">
               <q-item-section avatar>
                 <q-avatar
                   size="md"
                   text-color="white"
                   class="avatar-circle btn-rounded-iniciais"
                 >
                   {{ $iniciaisString(username) }}
                 </q-avatar>
               </q-item-section>

               <q-item-section>
                 <q-item-label>Olá! <b>{{ formatUsername(username) }}</b></q-item-label>
               </q-item-section>

             <!-- Menu do usuário -->
             <q-menu anchor="bottom right" self="top right">
               <q-list style="min-width: 100px">
                 <q-item-label header>Olá! <b>{{ username }}</b></q-item-label>
                 <q-item clickable v-close-popup @click="abrirModalUsuario">
                   <q-item-section>Perfil</q-item-section>
                 </q-item>
                 <q-item clickable v-close-popup @click="efetuarLogout">
                   <q-item-section>Sair</q-item-section>
                 </q-item>
                 <q-separator />
                 <q-item>
                   <q-item-section>
                     <vencimento />
                     <cSystemVersion />
                   </q-item-section>
                 </q-item>
               </q-list>
             </q-menu>
           </div>

           <q-separator />

         <q-scroll-area class="fit">
           <q-list padding :key="userProfile">
             <EssentialLink
               v-for="item in cObjMenu"
               :key="item.title"
               :title="item.title"
               :icon="item.icon"
               :routeName="item.routeName"
               :badge="item.badge"
             />
             <div v-if="userProfile === 'admin'">
               <q-separator spaced />
               <div class="q-mb-lg"></div>
               <EssentialLink v-if="exibirMenuEmpresas(item)"
                              :key="Empresas"
                              v-bind="{
                   title: 'Empresas',
                   caption: 'Configurações do SaaS',
                   icon: 'mdi-office-building',
                   routeName: 'empresas',
                 }" />
               <!-- <q-item-label header>Administração</q-item-label> -->
              <template v-for="item in menuDataAdmin">
                <EssentialLink v-if="exibirMenuBeta(item)" :key="item.title" v-bind="item" />
              </template>
              <EssentialLink v-if="exibirMenuBeta(item)"
                             :key="Configurações"
                             @submenu-mouseover="miniState = false"
                             @submenu-mouseout="miniState = true"
                             v-bind="{
                  title: 'Cadastros',
                  caption: 'Cadastros do sistema',
                  icon: 'mdi-list',
                  routeName: 'cadastros',
                  submenu: true,
                  menuType: 'cadastros'

                }" />
              <EssentialLink v-if="exibirMenuBeta(item)"
                             :key="Configurações"
                             @submenu-mouseover="miniState = false"
                             @submenu-mouseout="miniState = true"
                             v-bind="{
                  title: 'Configurações',
                  caption: 'Configurações do sistema',
                  icon: 'mdi-settings-2',
                  routeName: 'configuracoes',
                  submenu: true,
                  menuType: 'configuracoes'

                }" />
              <q-separator spaced />
            </div>

          </q-list>
        </q-scroll-area>

        <div class="absolute-bottom text-center row justify-start"
             :class="{ 'bg-grey-3': $q.dark.isActive }"
             style="height: 40px">
          <q-toggle size="xl"
                    keep-color
                    dense
                    class="text-bold q-ml-xs"
                    :class="$q.dark.isActive ? 'bg-black full-width' : ''"
                    :icon-color="$q.dark.isActive ? 'black' : 'white'"
                    :value="$q.dark.isActive"
                    :color="$q.dark.isActive ? 'grey-3' : 'black'"
                    checked-icon="mdi-white-balance-sunny"
                    unchecked-icon="mdi-weather-sunny"
                    @input="$setConfigsUsuario({ isDark: !$q.dark.isActive })">
            <q-tooltip content-class="text-body1 hide-scrollbar">
              {{ $q.dark.isActive ? 'Desativar' : 'Ativar' }} Modo Escuro (Dark Mode)
            </q-tooltip>
          </q-toggle>
        </div>
      </q-drawer>

      <q-page-container>
        <informative />
        <q-page class="q-pa-xs">
          <router-view />
        </q-page>
      </q-page-container>

      <ModalUsuario :isProfile="true"
                    :modalUsuario.sync="modalUsuario"
                    :usuarioEdicao.sync="usuario" />
    </q-layout>

  </div>
</template>

<script>
// const userId = +localStorage.getItem('userId')
import cSystemVersion from '../components/cSystemVersion.vue'
import { ListarWhatsapps } from 'src/service/sessoesWhatsapp'
import { ConsultarResumoTarefas } from 'src/service/tarefas'
import EssentialLink from 'components/EssentialLink.vue'
import socketInitial from './socketInitial'
import alertSound from 'src/assets/sound.mp3'
import silenceSound from 'src/assets/silence.mp3'
import alertInterno from 'src/assets/chatInterno.mp3'
import { format } from 'date-fns'
const username = localStorage.getItem('username')
import ModalUsuario from 'src/pages/usuarios/usuarios/ModalUsuario'
import { mapGetters } from 'vuex'
import { ListarConfiguracoes } from 'src/service/configuracoes'
import { RealizarLogout } from 'src/service/login'
import vencimento from '../components/vencimento.vue'
import informative from '../components/informative.vue'
import { socketIO } from 'src/utils/socket'
import { ConsultarTickets } from 'src/service/tickets'
import { listCountUnreadMessage, listCountUnreadMessageGroup } from 'src/service/chatInterno'
import { ListarVersao } from 'src/service/configuracoesgeneral'
import packageEnv from 'app/package.json'
const socket = socketIO()

const objMenu = [
  {
    title: 'Dashboard',
    caption: '',
    icon: 'mdi-home',
    routeName: 'home-dashboard'
  },
  {
    title: 'Atendimentos',
    caption: 'Lista de atendimentos',
    icon: 'mdi-whatsapp',
    routeName: 'chat-empty'
  },
  {
    title: 'Contatos',
    caption: 'Lista de contatos',
    icon: 'mdi-card-account-mail',
    routeName: 'contatos'
  },
  {
    title: 'CRM',
    caption: 'CRM',
    icon: 'mdi-monitor-dashboard',
    routeName: 'kanban'
  },
  {
    title: 'Chat Interno',
    caption: 'Chat',
    icon: 'mdi-forum-outline',
    routeName: 'chat-interno'
  },
  {
    title: 'Mensagens Rápidas',
    caption: 'Mensagens pré-definidas',
    icon: 'mdi-reply-all-outline',
    routeName: 'mensagens-rapidas'
  },
  {
    title: 'Tarefas',
    caption: 'Tarefas',
    icon: 'mdi-clipboard-list-outline',
    routeName: 'tarefas'
  },
  {
    title: 'Despedida',
    caption: 'Mensagens de despedida',
    icon: 'mdi-message-bulleted-off',
    routeName: 'despedida'
  },
  {
    title: 'Agendamentos',
    caption: 'Mensagens Agendadas',
    icon: 'eva-clock-outline',
    routeName: 'agendamentos'
  },
  {
    title: 'Ajuda',
    caption: 'Ajuda',
    icon: 'mdi-help',
    routeName: 'ajuda'
  }
]

const objMenuAdmin = [
  {
    title: 'Painel Atendimentos',
    caption: 'Visão geral dos atendimentos',
    icon: 'mdi-view-dashboard-variant',
    routeName: 'painel-atendimentos'
  },
  {
    title: 'Relatórios',
    caption: 'Relatórios gerais',
    icon: 'mdi-file-chart',
    routeName: 'relatorios'
  },
  {
    title: 'Financeiro',
    caption: 'Financeiro',
    icon: 'mdi-cash-multiple',
    routeName: 'financeiro'
  }
]

export default {
  name: 'MainLayout',
  mixins: [socketInitial],
  components: { EssentialLink, ModalUsuario, cSystemVersion, vencimento, informative },
  data () {
    return {
      delayed: 0,
      version: '',
      venceHoje: 0,
      whatsappId: null,
      username,
      domainExperimentalsMenus: ['@'],
      miniState: true,
      userProfile: 'user',
      modalUsuario: false,
      usuario: {},
      isSilentMode: false,
      alertSound,
      alertInterno,
      silenceSound,
      leftDrawerOpen: false,
      menuData: objMenu,
      menuDataAdmin: objMenuAdmin,
      countTickets: 0,
      ticketsList: [],
      notificacaoInternaNaoLida: '',
      TicketPendentes: ''
    }
  },
  computed: {
    cVersion () {
      return packageEnv.version // Computada para pegar do package.json
    },
    ...mapGetters(['notifications', 'notifications_p', 'whatsapps', 'showMenu', 'chatFocado', 'notificacaoChatInterno', 'notificacoesChat', 'notificacaoTicket']),
    cProblemaConexao () {
      const idx = this.whatsapps.findIndex(w =>
        ['PAIRING', 'TIMEOUT', 'DISCONNECTED'].includes(w.status)
      )
      return idx !== -1
    },
    cQrCode () {
      const idx = this.whatsapps.findIndex(
        w => w.status === 'qrcode' || w.status === 'DESTROYED'
      )
      return idx !== -1
    },
    cOpening () {
      const idx = this.whatsapps.findIndex(w => w.status === 'OPENING')
      return idx !== -1
    },
    cUsersApp () {
      return this.$store.state.usersApp
    },
    cObjMenu() {
      return objMenu.map(menu => {
        const menuItem = { ...menu }

        if (menu.routeName === 'chat-empty' && this.TicketPendentes > 0) {
          menuItem.badge = this.TicketPendentes
        }

        if (menu.routeName === 'chat-interno' && this.notificacaoInternaNaoLida > 0) {
          menuItem.badge = this.notificacaoInternaNaoLida
        }

        if (menu.routeName === 'tarefas') {
          const totalTarefas = (this.delayed || 0) + (this.venceHoje || 0)
          if (totalTarefas > 0) {
            menuItem.badge = totalTarefas
          }
        }

        return menuItem
      })
    }
  },
  watch: {
    notificacaoChatInterno: {
      handler() {
        this.listarMensagens()
        if (this.$router.currentRoute.fullPath.indexOf('atendimento-Interno') < 0 ||
          !this.chatFocado.id ||
          this.chatFocado.id !== this.notificacaoChatInterno.senderId) {
          const audio = new Audio(alertInterno)
          audio.play()

          if ('Notification' in window && Notification.permission === 'granted') {
            const isGroupMessage = !!this.notificacaoChatInterno.groupId
            const title = isGroupMessage
              ? `Chat Int. Grupo ${this.notificacaoChatInterno.groupName}`
              : `Chat Interno de ${this.notificacaoChatInterno.sender.name}`

            const messageBody = isGroupMessage
              ? `${this.notificacaoChatInterno.sender.name}\n${this.notificacaoChatInterno.text} - ${format(new Date(), 'HH:mm')}`
              : `${this.notificacaoChatInterno.text} - ${format(new Date(), 'HH:mm')}`

            const options = {
              body: messageBody,
              tag: this.notificacaoChatInterno.id,
              renotify: true
            }

            const notification = new Notification(title, options)

            notification.onclick = e => {
              e.preventDefault()
              window.focus()
              this.$router.push({ name: 'chat-interno' })
            }
          }
        }
      }
    },
    notificacaoTicket: {
      handler() {
        // console.log('interno', this.$route.name)
        this.consultarTickets()
      }
    },
    $route(to, from) {
      if (from.name === 'tarefas') {
        setTimeout(() => {
          this.getTaskSummary()
        }, 100)
      }
      if (from.name === 'chat-interno') {
        setTimeout(() => {
          this.listarMensagens()
        }, 100)
      }
    }
  },
  methods: {
    toggleSilentMode() {
      this.isSilentMode = !this.isSilentMode
      localStorage.setItem('silentMode', this.isSilentMode)
      window.location.reload()
    },
    async getTaskSummary() {
      const owner = localStorage.getItem('username')
      try {
        const response = await ConsultarResumoTarefas({ owner })
        this.delayed = response.data.delayed
        this.venceHoje = response.data.venceHoje
      } catch (error) {
        console.error('Erro ao consultar resumo de tarefas:', error)
      }
    },
    formatUsername(username, maxLength = 20) {
      if (!username) {
        return ''
      }

      const nameParts = username.trim().split(' ')

      if (nameParts.length >= 3) {
        const formattedName = `${nameParts[0]} ${nameParts[nameParts.length - 1]}`
        if (formattedName.length > maxLength) {
          return formattedName.substring(0, maxLength - 3) + '...'
        }
        return formattedName
      }

      if (username.length > maxLength) {
        return username.substring(0, maxLength - 3) + '...'
      }

      return username
    },
    async listarMensagens() {
      try {
        const [messageResponse, groupResponse] = await Promise.all([
          listCountUnreadMessage(this.usuario.userId),
          listCountUnreadMessageGroup(this.usuario.userId)
        ])

        this.notificacaoInternaNaoLida =
          (messageResponse.data?.count || 0) +
          (groupResponse.data?.count || 0)
      } catch (error) {
        console.error('Erro ao listar mensagens:', error)
        this.notificacaoInternaNaoLida = 0
      }
    },
    reloadPage() {
      window.location.reload()
    },
    exibirMenuBeta(itemMenu) {
      if (!itemMenu?.isBeta) return true
      for (const domain of this.domainExperimentalsMenus) {
        if (this.usuario.email.indexOf(domain) !== -1) return true
      }
      return false
    },
    exibirMenuEmpresas(itemMenu) {
      const user = JSON.parse(localStorage.getItem('usuario'))
      if (user.tenantId != 1) {
        return false
      }
      return true
    },
    async listarWhatsapps() {
      const { data } = await ListarWhatsapps()
      this.$store.commit('LOAD_WHATSAPPS', data)
    },
    validaTelaAdmin(itemMenu) {
      const user = JSON.parse(localStorage.getItem('usuario'))
      if (itemMenu.routeName === 'empresas' && user.tenantId != 1) return false
      return true
    },
    async abrirModalUsuario () {
      this.modalUsuario = true
    },
    async efetuarLogout () {
      try {
        await RealizarLogout(this.usuario)
        localStorage.removeItem('token')
        localStorage.removeItem('username')
        localStorage.removeItem('profile')
        localStorage.removeItem('userId')
        localStorage.removeItem('queues')
        localStorage.removeItem('usuario')
        localStorage.removeItem('filtrosAtendimento')

        this.$router.go({ name: 'login', replace: true })
      } catch (error) {
        this.$notificarErro('Não foi possível realizar logout', error)
      }
    },
    async listarConfiguracoes () {
      const { data } = await ListarConfiguracoes()
      localStorage.setItem('configuracoes', JSON.stringify(data))
    },
    conectarSocket (usuario) {
      socket.on(`${usuario.tenantId}:chat:updateOnlineBubbles`, data => {
        this.$store.commit('SET_USERS_APP', data)
      })
    },
    atualizarUsuario () {
      this.usuario = JSON.parse(localStorage.getItem('usuario'))
      if (this.usuario.status === 'offline') {
        socket.emit(`${this.usuario.tenantId}:setUserIdle`)
      }
      if (this.usuario.status === 'online') {
        socket.emit(`${this.usuario.tenantId}:setUserActive`)
      }
    },
    async consultarTickets () {
      const params = {
        searchParam: '',
        pageNumber: 1,
        status: ['open', 'pending'],
        showAll: false,
        count: null,
        queuesIds: [],
        tagsIds: [],
        withUnreadMessages: true,
        isNotAssignedUser: false,
        includeNotQueueDefined: true,
        useradmId: [],
        whatsappIds: []
        // date: new Date(),
      }
      try {
        const { data } = await ConsultarTickets(params)
        this.countTickets = data.count // count total de tickets no status
        // console.log('data.count', data.count)
        // this.ticketsList = data.tickets
        // console.log(data)
        this.$store.commit('UPDATE_NOTIFICATIONS', data)
        setTimeout(() => {
          this.$store.commit('UPDATE_NOTIFICATIONS', data)
        }, 500)
        // this.$store.commit('SET_HAS_MORE', data.hasMore)
        // console.log(this.notifications)
      } catch (err) {
        console.error('Erro ao consultar tickets:', err)
        if (err && err.data.error === "Internal server error: TypeError: Cannot read properties of null (reading 'profile')") {
          console.warn('Erro 500 detectado. Chamando efetuarLogout...')
          this.efetuarLogout()
        } else {
          console.warn('Erro inesperado:', err)
        }
      }
      const params2 = {
        searchParam: '',
        pageNumber: 1,
        status: ['pending'],
        showAll: false,
        count: null,
        queuesIds: [],
        tagsIds: [],
        withUnreadMessages: false,
        isNotAssignedUser: false,
        includeNotQueueDefined: true,
        useradmId: [],
        whatsappIds: []
        // date: new Date(),
      }
      try {
        const { data } = await ConsultarTickets(params2)
        this.countTickets = data.count
        this.TicketPendentes = data.count
        // console.log('data.count2', data.count)
        // this.ticketsList = data.tickets
        // console.log(data)
        this.$store.commit('UPDATE_NOTIFICATIONS_P', data)
        setTimeout(() => {
          this.$store.commit('UPDATE_NOTIFICATIONS_P', data)
        }, 500)
        // this.$store.commit('SET_HAS_MORE', data.hasMore)
        // console.log(this.notifications)
      } catch (err) {
        console.error('Erro ao consultar tickets:', err)
        if (err && err.data.error === "Internal server error: TypeError: Cannot read properties of null (reading 'profile')") {
          console.warn('Erro 500 detectado. Chamando efetuarLogout...')
          this.efetuarLogout()
        } else {
          console.warn('Erro inesperado:', err)
        }
      }
    },
    async clearCache () {
      if (window.caches) {
        const cacheNames = await caches.keys()
        for (const name of cacheNames) {
          await caches.delete(name)
        }
      }
      localStorage.clear()
      sessionStorage.clear()
      this.$q.notify('Feche o navegador e abra novamente para carregar nova versão.')

      // Redireciona para a página de login
      window.location.href = '/#/login'
    },
    async loadversao() {
      try {
        // Chamada para o backend
        const response = await ListarVersao()

        // Desestruturação dos valores retornados pela API
        const { version } = response.data

        console.log('Backend version:', version)
        console.log('Frontend version:', this.cVersion)

        // Verifica se a versão do backend é diferente da versão do frontend
        if (version !== this.cVersion) {
          console.log('Versão diferente detectada. Limpando o cache e redirecionando...')
          await this.clearCache()
        } else {
          console.log('Versões coincidem. Nenhuma ação necessária.')
        }

        // Atualiza a variável 'version' do data
        this.version = version
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    }
  },
  async mounted () {
    this.loadversao()
    this.getTaskSummary()
    await this.consultarTickets()
    await this.listarMensagens()
    this.$root.$on('submenu-mouseover', () => {
      this.miniState = false
    })
    this.$root.$on('submenu-mouseout', () => {
      this.miniState = true
    })
    const savedSilentMode = localStorage.getItem('silentMode')
    if (savedSilentMode !== null) {
      this.isSilentMode = JSON.parse(savedSilentMode)
    }
    await this.consultarTickets()
    this.atualizarUsuario()
    await this.listarWhatsapps()
    await this.listarConfiguracoes()

    this.socket.on('disconnect', () => {
      console.log('Socket disconnected. Trying to reconnect...')
      this.socket.connect()
    })
    if ('Notification' in window) {
      if (Notification.permission !== 'granted') {
        await Notification.requestPermission()
      }

      this.usuario = JSON.parse(localStorage.getItem('usuario'))
      this.userProfile = localStorage.getItem('profile')

      await this.conectarSocket(this.usuario)

      this.atualizarUsuario()
      await this.listarWhatsapps()
      await this.listarConfiguracoes()

      this.socket.on('chat:update', this.handlerNotifications)
    }
    this.usuario = JSON.parse(localStorage.getItem('usuario'))
    this.userProfile = localStorage.getItem('profile')
    await this.conectarSocket(this.usuario)
  },
  destroyed () {
    socket.disconnect()
  }
}
</script>
<style scoped>
.q-img__image {
  background-size: contain;
}

.drawer-container {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.drawer-header {
  padding: 8px 0;
}

.drawer-menu {
  flex: 1;
  overflow-y: auto;
}

.drawer-footer {
  padding: 8px 0;
  border-top: 1px solid rgba(0, 0, 0, 0.12);
}

/* Esconde a scrollbar no Chrome/Safari/Opera */
.drawer-menu::-webkit-scrollbar {
  display: none;
}

/* Esconde a scrollbar no IE/Edge/Firefox */
.drawer-menu {
  -ms-overflow-style: none;
  scrollbar-width: none;
}

.header-item {
  min-height: 48px;
}

</style>
